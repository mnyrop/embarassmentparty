$(document).ready(function() {
  $('.links').jqFloat({
    width: 20,
    height: 20,
    speed: 1500
  });
  $('.artgiffy').jqFloat({
    width: 80,
    height: 80,
    speed: 3100
  });
  $('.cgiffy').jqFloat({
    width: 30,
    height: 30,
    speed: 5100
  });
  $('.giffy').jqFloat({
    width: 80,
    height: 80,
    speed: 5100
  });
  $('.container').jqFloat({
    width: 60,
    height: 60,
    speed: 4500
  });
});